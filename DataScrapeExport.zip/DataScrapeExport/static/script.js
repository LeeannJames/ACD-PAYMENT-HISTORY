// Payment Data Scraper JavaScript functionality

document.addEventListener('DOMContentLoaded', function() {
    // Initialize components
    initializeScrapeForm();
    initializeTooltips();
    initializeTableFeatures();
});

function initializeScrapeForm() {
    const scrapeForm = document.getElementById('scrapeForm');
    const scrapeBtn = document.getElementById('scrapeBtn');
    const btnText = document.getElementById('btnText');
    const btnSpinner = document.getElementById('btnSpinner');
    
    if (scrapeForm && scrapeBtn) {
        scrapeForm.addEventListener('submit', function(e) {
            // Show loading state
            scrapeBtn.disabled = true;
            scrapeBtn.classList.add('loading');
            btnText.textContent = 'Scraping...';
            btnSpinner.classList.remove('d-none');
            
            // Validate URL
            const urlInput = document.getElementById('url');
            const url = urlInput.value.trim();
            
            if (!isValidUrl(url)) {
                e.preventDefault();
                showAlert('Please enter a valid URL starting with http:// or https://', 'error');
                resetButton();
                return false;
            }
            
            // Form will submit normally, loading state will persist until page reload
        });
    }
    
    function resetButton() {
        if (scrapeBtn) {
            scrapeBtn.disabled = false;
            scrapeBtn.classList.remove('loading');
            btnText.textContent = 'Scrape Payment Data';
            btnSpinner.classList.add('d-none');
        }
    }
}

function isValidUrl(string) {
    try {
        const url = new URL(string);
        return url.protocol === 'http:' || url.protocol === 'https:';
    } catch (_) {
        return false;
    }
}

function showAlert(message, type = 'info') {
    // Create alert element
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type === 'error' ? 'danger' : type} alert-dismissible fade show`;
    alertDiv.innerHTML = `
        <i class="fas fa-${type === 'error' ? 'exclamation-triangle' : 'info-circle'} me-2"></i>
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    // Insert at the top of the main container
    const container = document.querySelector('.container, .container-fluid');
    if (container) {
        container.insertBefore(alertDiv, container.firstChild);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (alertDiv.parentNode) {
                alertDiv.remove();
            }
        }, 5000);
    }
}

function initializeTooltips() {
    // Initialize Bootstrap tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

function initializeTableFeatures() {
    const table = document.querySelector('.table');
    if (!table) return;
    
    // Initialize variance calculations
    initializeVarianceCalculations();
    
    // Add row hover effects
    const rows = table.querySelectorAll('tbody tr');
    rows.forEach(row => {
        row.addEventListener('mouseenter', function() {
            this.classList.add('table-active');
        });
        
        row.addEventListener('mouseleave', function() {
            this.classList.remove('table-active');
        });
    });
    
    // Add cell click to copy functionality (excluding input fields)
    const cells = table.querySelectorAll('tbody td');
    cells.forEach(cell => {
        if (!cell.querySelector('input')) {
            cell.addEventListener('click', function() {
                const text = this.textContent.trim();
                if (text && text !== '—') {
                    copyToClipboard(text);
                    showToast('Copied to clipboard: ' + text.substring(0, 30) + (text.length > 30 ? '...' : ''));
                }
            });
            
            // Add pointer cursor for clickable cells
            cell.style.cursor = 'pointer';
            cell.title = 'Click to copy';
        }
    });
}

function initializeVarianceCalculations() {
    // Set up PassBook input listeners for both Principal and CBU types
    const passbookInputs = document.querySelectorAll('.passbook-input');
    passbookInputs.forEach(input => {
        input.addEventListener('input', function() {
            const rowIndex = this.dataset.rowIndex;
            const passbookType = this.dataset.passbookType;
            
            if (passbookType === 'principal') {
                calculatePrincipalVariance(rowIndex);
            } else if (passbookType === 'cbu') {
                calculateCBUVariance(rowIndex);
            } else if (passbookType === 'cbu_withdraw') {
                calculateCBUWithdrawVariance(rowIndex);
            }
        });
        
        input.addEventListener('change', function() {
            const rowIndex = this.dataset.rowIndex;
            const passbookType = this.dataset.passbookType;
            
            if (passbookType === 'principal') {
                calculatePrincipalVariance(rowIndex);
            } else if (passbookType === 'cbu') {
                calculateCBUVariance(rowIndex);
            } else if (passbookType === 'cbu_withdraw') {
                calculateCBUWithdrawVariance(rowIndex);
            }
        });
    });
    
    // Calculate initial variances for all rows
    passbookInputs.forEach(input => {
        const rowIndex = input.dataset.rowIndex;
        const passbookType = input.dataset.passbookType;
        
        if (passbookType === 'principal') {
            calculatePrincipalVariance(rowIndex);
        } else if (passbookType === 'cbu') {
            calculateCBUVariance(rowIndex);
        } else if (passbookType === 'cbu_withdraw') {
            calculateCBUWithdrawVariance(rowIndex);
        }
    });
}

function calculatePrincipalVariance(rowIndex) {
    // Get values for Principal variance calculation
    const principalElement = document.querySelector(`[data-row-index="${rowIndex}"][data-column="principal"]`);
    const penElement = document.querySelector(`[data-row-index="${rowIndex}"][data-column="pen"]`);
    const passbookInput = document.querySelector(`[data-row-index="${rowIndex}"][data-passbook-type="principal"]`);
    const varianceDisplay = document.querySelector(`[data-row-index="${rowIndex}"][data-variance-type="principal"]`);
    
    if (!principalElement || !penElement || !passbookInput || !varianceDisplay) {
        return;
    }
    
    // Parse values (remove commas and convert to numbers)
    const principal = parseFloat(principalElement.textContent.replace(/,/g, '')) || 0;
    const pen = parseFloat(penElement.textContent.replace(/,/g, '')) || 0;
    const passbook = parseFloat(passbookInput.value) || 0;
    
    // Calculate variance: Principal + Pen - PassBook
    const variance = principal + pen - passbook;
    
    // Format and display the result
    const formattedVariance = variance.toFixed(2);
    varianceDisplay.textContent = formattedVariance;
    
    // Color coding based on variance value
    if (variance > 0) {
        varianceDisplay.style.color = 'var(--bs-success)';
    } else if (variance < 0) {
        varianceDisplay.style.color = 'var(--bs-danger)';
    } else {
        varianceDisplay.style.color = 'var(--bs-warning)';
    }
    
    // Update the data for Excel export
    updateExportData(rowIndex, 'Principal_PassBook', passbook);
    updateExportData(rowIndex, 'Principal_Variance', variance);
}

function calculateCBUVariance(rowIndex) {
    // Get values for CBU variance calculation (only CBU value)
    const cbuElement = document.querySelector(`[data-row-index="${rowIndex}"][data-column="cbu"]`);
    const passbookInput = document.querySelector(`[data-row-index="${rowIndex}"][data-passbook-type="cbu"]`);
    const varianceDisplay = document.querySelector(`[data-row-index="${rowIndex}"][data-variance-type="cbu"]`);
    
    if (!cbuElement || !passbookInput || !varianceDisplay) {
        return;
    }
    
    // Parse values (remove commas and convert to numbers)
    const cbu = parseFloat(cbuElement.textContent.replace(/,/g, '')) || 0;
    const passbook = parseFloat(passbookInput.value) || 0;
    
    // Calculate variance: CBU - PassBook
    const variance = cbu - passbook;
    
    // Format and display the result
    const formattedVariance = variance.toFixed(2);
    varianceDisplay.textContent = formattedVariance;
    
    // Color coding based on variance value
    if (variance > 0) {
        varianceDisplay.style.color = 'var(--bs-success)';
    } else if (variance < 0) {
        varianceDisplay.style.color = 'var(--bs-danger)';
    } else {
        varianceDisplay.style.color = 'var(--bs-warning)';
    }
    
    // Update the data for Excel export
    updateExportData(rowIndex, 'CBU_PassBook', passbook);
    updateExportData(rowIndex, 'CBU_Variance', variance);
}

function calculateCBUWithdrawVariance(rowIndex) {
    // Get values for CBU withdraw variance calculation (only CBU withdraw value)
    const cbuWithdrawElement = document.querySelector(`[data-row-index="${rowIndex}"][data-column="cbu_withdraw"]`);
    const passbookInput = document.querySelector(`[data-row-index="${rowIndex}"][data-passbook-type="cbu_withdraw"]`);
    const varianceDisplay = document.querySelector(`[data-row-index="${rowIndex}"][data-variance-type="cbu_withdraw"]`);
    
    if (!cbuWithdrawElement || !passbookInput || !varianceDisplay) {
        return;
    }
    
    // Parse values (remove commas and convert to numbers)
    const cbuWithdraw = parseFloat(cbuWithdrawElement.textContent.replace(/,/g, '')) || 0;
    const passbook = parseFloat(passbookInput.value) || 0;
    
    // Calculate variance: CBU withdraw - PassBook
    const variance = cbuWithdraw - passbook;
    
    // Format and display the result
    const formattedVariance = variance.toFixed(2);
    varianceDisplay.textContent = formattedVariance;
    
    // Color coding based on variance value
    if (variance > 0) {
        varianceDisplay.style.color = 'var(--bs-success)';
    } else if (variance < 0) {
        varianceDisplay.style.color = 'var(--bs-danger)';
    } else {
        varianceDisplay.style.color = 'var(--bs-warning)';
    }
    
    // Update the data for Excel export
    updateExportData(rowIndex, 'CBU_withdraw_PassBook', passbook);
    updateExportData(rowIndex, 'CBU_withdraw_Variance', variance);
}

function updateExportData(rowIndex, column, value) {
    // Store updated values for Excel export
    if (!window.exportData) {
        window.exportData = {};
    }
    if (!window.exportData[rowIndex]) {
        window.exportData[rowIndex] = {};
    }
    window.exportData[rowIndex][column] = value;
    
    // Send update to backend with debouncing
    clearTimeout(window.updateTimeout);
    window.updateTimeout = setTimeout(() => {
        sendDataUpdate();
    }, 500);
}

function sendDataUpdate() {
    if (!window.exportData || Object.keys(window.exportData).length === 0) {
        return;
    }
    
    // Get session ID from the current URL or download button
    const sessionId = getSessionId();
    if (!sessionId) {
        console.error('Session ID not found');
        return;
    }
    
    fetch(`/update_data/${sessionId}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(window.exportData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            console.log('Data updated successfully');
        } else {
            console.error('Error updating data:', data.error);
        }
    })
    .catch(error => {
        console.error('Error sending update:', error);
    });
}

function getSessionId() {
    // Extract session ID from download button href or URL
    const downloadBtn = document.querySelector('a[href*="/download/"]');
    if (downloadBtn) {
        const href = downloadBtn.getAttribute('href');
        const match = href.match(/\/download\/([^\/]+)/);
        return match ? match[1] : null;
    }
    
    // Fallback: extract from current URL if on preview page
    const urlMatch = window.location.pathname.match(/\/preview\/([^\/]+)/);
    return urlMatch ? urlMatch[1] : null;
}

function copyToClipboard(text) {
    if (navigator.clipboard && window.isSecureContext) {
        // Use modern clipboard API
        navigator.clipboard.writeText(text);
    } else {
        // Fallback for older browsers
        const textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        textArea.style.top = '-999999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        document.execCommand('copy');
        textArea.remove();
    }
}

function showToast(message, type = 'success') {
    // Create toast container if it doesn't exist
    let toastContainer = document.getElementById('toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.id = 'toast-container';
        toastContainer.className = 'toast-container position-fixed bottom-0 end-0 p-3';
        toastContainer.style.zIndex = '9999';
        document.body.appendChild(toastContainer);
    }
    
    // Create toast element
    const toastId = 'toast-' + Date.now();
    const toastDiv = document.createElement('div');
    toastDiv.id = toastId;
    toastDiv.className = `toast align-items-center text-bg-${type} border-0`;
    toastDiv.setAttribute('role', 'alert');
    toastDiv.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                ${message}
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `;
    
    toastContainer.appendChild(toastDiv);
    
    // Initialize and show toast
    const toast = new bootstrap.Toast(toastDiv, {
        autohide: true,
        delay: 3000
    });
    toast.show();
    
    // Remove toast element after it's hidden
    toastDiv.addEventListener('hidden.bs.toast', function() {
        this.remove();
    });
}

// Handle download button clicks
document.addEventListener('click', function(e) {
    if (e.target.closest('.btn[href*="download"]')) {
        const btn = e.target.closest('.btn');
        const originalText = btn.innerHTML;
        
        // Show downloading state
        btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Preparing Download...';
        btn.classList.add('disabled');
        
        // Reset button after download starts (delay to allow browser to start download)
        setTimeout(() => {
            btn.innerHTML = originalText;
            btn.classList.remove('disabled');
            showToast('Download started successfully!', 'success');
        }, 2000);
    }
});

// Handle URL input validation
const urlInput = document.getElementById('url');
if (urlInput) {
    urlInput.addEventListener('input', function() {
        const url = this.value.trim();
        const isValid = !url || isValidUrl(url);
        
        if (isValid) {
            this.classList.remove('is-invalid');
            this.classList.add('is-valid');
        } else {
            this.classList.remove('is-valid');
            this.classList.add('is-invalid');
        }
    });
    
    // Clear validation classes when empty
    urlInput.addEventListener('blur', function() {
        if (!this.value.trim()) {
            this.classList.remove('is-valid', 'is-invalid');
        }
    });
}

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    // Ctrl+Enter or Cmd+Enter to submit form
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        const form = document.getElementById('scrapeForm');
        if (form) {
            form.submit();
        }
    }
    
    // Escape to clear form
    if (e.key === 'Escape') {
        const urlInput = document.getElementById('url');
        if (urlInput && document.activeElement === urlInput) {
            urlInput.value = '';
            urlInput.classList.remove('is-valid', 'is-invalid');
        }
    }
});

// Auto-focus URL input on page load
window.addEventListener('load', function() {
    const urlInput = document.getElementById('url');
    if (urlInput) {
        urlInput.focus();
    }
});
